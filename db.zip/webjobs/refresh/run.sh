#!/usr/bin/env bash
set -euo pipefail
cd /home/site/wwwroot
node src/refresh-cli.js
