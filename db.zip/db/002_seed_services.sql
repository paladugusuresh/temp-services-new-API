-- Seed common temporary services (keys match UI exactly)
INSERT INTO services (key, name, unit) VALUES
  ('junk-removal', 'Junk Removal', 'per load'),
  ('house-cleaning', 'House Cleaning', 'per visit'),
  ('lawn-mowing', 'Lawn Mowing', 'per visit'),
  ('snow-removal', 'Snow Removal', 'per visit'),
  ('handyman', 'Handyman Service', 'per hour'),
  ('plumber', 'Plumber', 'per hour'),
  ('electrician', 'Electrician', 'per hour'),
  ('hvac', 'HVAC Technician', 'per hour'),
  ('moving', 'Moving Service', 'per hour'),
  ('pest-control', 'Pest Control', 'per visit'),
  ('painting', 'Painting Service', 'per hour'),
  ('roofing', 'Roofing Service', 'per square foot'),
  ('carpentry', 'Carpentry Service', 'per hour'),
  ('landscaping', 'Landscaping Service', 'per hour'),
  ('pet-sitting', 'Pet Sitting', 'per day')
ON CONFLICT (key) DO NOTHING;
